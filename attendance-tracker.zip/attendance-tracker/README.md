# 📊 MBBS Attendance Tracker
### III MBBS · VII TERM · I3 Batch — Ritesh Kumar Pathak & Iru Raut

A real-time attendance tracker hosted **free** on GitHub Pages.  
Auto-deploys every time you push an update. No server. No cost.

---

## 🌐 Live URL (after setup)
```
https://YOUR_GITHUB_USERNAME.github.io/attendance-tracker/
```

---

## 🚀 Complete Setup Guide (Step by Step)

### STEP 1 — Create a GitHub Account
1. Go to **https://github.com**
2. Click **"Sign up"**
3. Enter your email, create a password, choose a username
4. Verify your email
5. Choose the **Free** plan

---

### STEP 2 — Create a New Repository
1. After logging in, click the **"+"** icon (top right) → **"New repository"**
2. Fill in:
   - **Repository name:** `attendance-tracker`
   - **Description:** `MBBS Attendance Tracker`
   - **Visibility:** ✅ Public *(required for free GitHub Pages)*
   - **Initialize with README:** ✅ Check this
3. Click **"Create repository"**

---

### STEP 3 — Upload the Files
You need to upload these files (provided in this folder):

| File | Location in repo |
|------|-----------------|
| `index.html` | Root (top level) |
| `attendance_data.json` | Root (top level) |
| `deploy.yml` | `.github/workflows/deploy.yml` |

#### Method A — Upload via GitHub Website (Easiest)
1. In your new repo, click **"Add file"** → **"Upload files"**
2. Drag and drop `index.html` and `attendance_data.json`
3. Click **"Commit changes"**

#### Then create the workflow file:
1. Click **"Add file"** → **"Create new file"**
2. In the filename box, type exactly: `.github/workflows/deploy.yml`
   *(GitHub will auto-create the folders)*
3. Copy-paste the contents of `deploy.yml` into the editor
4. Click **"Commit new file"**

---

### STEP 4 — Enable GitHub Pages
1. In your repository, go to **Settings** (top menu)
2. Scroll down to **"Pages"** (left sidebar)
3. Under **"Source"**, select **"GitHub Actions"**
4. Click **Save**

---

### STEP 5 — Trigger the First Deploy
1. Go to **Actions** tab in your repository
2. You should see **"Deploy Attendance Tracker to GitHub Pages"**
3. Click on it → Click **"Run workflow"** → **"Run workflow"**
4. Wait ~60 seconds for the green ✅

---

### STEP 6 — Visit Your Live Site 🎉
```
https://YOUR_GITHUB_USERNAME.github.io/attendance-tracker/
```
Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username.

---

## 📱 How to Use the Tracker

| Action | How |
|--------|-----|
| **Switch student** | Click "Ritesh" or "Iru" tab at the top |
| **Mark Present** | Click ✓ Present on any subject card |
| **Mark Absent** | Click ✗ Absent on any subject card |
| **Filter subjects** | Use All / Critical / At Risk / Safe pills |
| **View history** | Scroll to "Recent Updates" section |
| **Reset data** | Click "↺ Reset to baseline" |

> ⚠️ **Note:** Data is saved in your browser's local storage.  
> It persists across sessions on the same device/browser.

---

## 🔄 How GitHub Automation Works

```
You edit attendance_data.json
         ↓
git push to main branch
         ↓
GitHub Actions auto-triggers
         ↓
Deploys updated site to GitHub Pages
         ↓
Live URL updates within ~60 seconds
```

Every time you push changes to the `main` branch,  
GitHub Actions **automatically redeploys** your site. No manual steps!

---

## 📋 Criteria Reference

| Subject Type | Minimum Required |
|---|---|
| Theory | **75%** |
| Practical | **80%** |

### Status Legend
| Color | Meaning |
|---|---|
| 🟢 SAFE | At or above required % |
| 🟡 WARNING | Within 5% below required |
| 🟠 DANGER | 6–15% below required |
| 🔴 CRITICAL | More than 15% below required |

---

## 📁 File Structure
```
attendance-tracker/
├── index.html              ← Main tracker app (all-in-one)
├── attendance_data.json    ← Baseline data (31 Jan 2026)
├── README.md               ← This file
└── .github/
    └── workflows/
        └── deploy.yml      ← GitHub Actions auto-deploy
```

---

## 🛠️ Updating Attendance Data Manually

If you want to bulk-update attendance numbers:

1. Open `attendance_data.json` in GitHub (click the file → pencil icon)
2. Edit the `held` and `attended` numbers for any subject
3. Click **"Commit changes"**
4. GitHub Actions auto-deploys the update in ~60 seconds

---

## ❓ Troubleshooting

| Problem | Solution |
|---|---|
| Site shows 404 | Wait 2 min after first deploy, check Pages settings |
| Actions not running | Check `.github/workflows/deploy.yml` exists |
| Data not saving | Browser local storage must be enabled |
| Wrong URL | Make sure repo is named exactly `attendance-tracker` |

---

*Made for III MBBS I3 Batch · Baseline: 31 January 2026*
